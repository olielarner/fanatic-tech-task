import $ from 'jquery';

export default class TextImageAndCta {
	$el = $('section.text-image-and-cta');

	constructor() {}

	init() {}
}
